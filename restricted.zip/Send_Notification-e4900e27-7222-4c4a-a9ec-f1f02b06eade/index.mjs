import { SNSClient, PublishCommand } from "@aws-sdk/client-sns";
import { CognitoIdentityProviderClient, AdminGetUserCommand } from '@aws-sdk/client-cognito-identity-provider';

const config = { region: process.env.region };
const snsClient = new SNSClient(config);
const cognitoClient = new CognitoIdentityProviderClient(config);

export const handler = async (event) => {
    let receivedEvent = event.Records || event;
    for (const record of receivedEvent) {
        console.log(record);
        if (record.eventName === 'INSERT') {
            const newItem = record.dynamodb.NewImage;
            if (newItem.PK.S.startsWith("THREAD#")) {
                const username = newItem.author.S;
                const userDetails = await retrieveUserDetails(username);
                const name = userDetails.name;

                let filler = '';
                if (newItem.SK.S.startsWith('COMMENT#')) {
                    filler = 'comment';
                }
                else if (newItem.SK.S.startsWith('THREAD#')) {
                    filler = 'thread';
                }

                // Convert Unix timestamp to milliseconds
                const timestamp = parseInt(newItem.created_dt.N);
                let datetime = new Date(timestamp);

                if (isNaN(datetime.getTime())) {
                    datetime = new Date();
                }

                const subject = "Corkboard Created Post";
                const body = `A new ${filler} has been posted in Corkboard by ${name} on ${datetime.toString()}.`;

                await sendEmail(subject, body);
            }
        }
    }
};

const sendEmail = async (subject, body) => {
    const params = {
        TopicArn: process.env.sns,
        Message: body,
        Subject: subject
    };

    try {
        await snsClient.send(new PublishCommand(params));
        console.log("Notification was published successfully.");
    }
    catch (error) {
        console.error("Error sending email:", error);
    }
};

const retrieveUserDetails = async (username) => {
    try {
        const command = new AdminGetUserCommand({
            UserPoolId: process.env.userpool,
            Username: username
        });
        const response = await cognitoClient.send(command);

        const attributes = response.UserAttributes || [];
        const nameAttribute = attributes.find(attr => attr.Name === 'name');
        const name = nameAttribute ? nameAttribute.Value : 'Name attribute not found';

        return { name };
    }
    catch (err) {
        console.error('Error retrieving user details:', err);
        return { email: 'Error retrieving email' }; // Default fallback
    }
};
