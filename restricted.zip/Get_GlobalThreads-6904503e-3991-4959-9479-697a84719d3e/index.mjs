import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { CognitoIdentityProviderClient, AdminGetUserCommand } from '@aws-sdk/client-cognito-identity-provider';

const config = { region: process.env.region };
const cognitoClient = new CognitoIdentityProviderClient(config);
const ddbClient = new DynamoDBClient(config);
const docClient = DynamoDBDocumentClient.from(ddbClient);

const cors = {
  'Access-Control-Allow-Methods': 'GET',
  'Access-Control-Allow-Origin': 'https://d1wx3p39zc5jck.cloudfront.net',
  'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token'
};

export const handler = async (event) => {
  const params = {
    TableName: process.env.table,
    IndexName: 'globalthread-index',
    KeyConditionExpression: '#comment = :cid and begins_with(SK, :sk)',
    ExpressionAttributeNames: {
      '#comment': 'comment'
    },
    ExpressionAttributeValues: {
      ':cid': 'NA',
      ':sk': 'THREAD#'
    },
    ScanIndexForward: false
  };

  const follow = {
    TableName: process.env.table,
    KeyConditionExpression: 'PK = :pk and begins_with(SK, :sk)',
    ExpressionAttributeValues: {
      ':pk': `USER#${event.requestContext.authorizer.claims['username']}`,
      ':sk': 'FOLLOW#'
    }
  };

  try {
    const [threadData, followData] = await Promise.all([
      docClient.send(new QueryCommand(params)),
      docClient.send(new QueryCommand(follow))
    ]);

    // Enrich thread data with user details
    const enrichedThreads = await Promise.all((threadData.Items || []).map(async (item) => {
      if (item.PK && item.PK.startsWith('THREAD#')) {
        const userDetails = await retrieveUserDetails(item.author);
        return {
          ...item,
          userDetails
        };
      }
      return item;
    }));

    return {
      statusCode: 200,
      headers: cors,
      body: JSON.stringify({
        threads: enrichedThreads,
        follows: followData.Items || []
      })
    };
  } catch (error) {
    console.error('Error in handler:', error);
    return {
      statusCode: 400,
      headers: cors,
      body: JSON.stringify({ error: 'Could not fetch data', details: error.message })
    };
  }
};

const retrieveUserDetails = async (username) => {
  try {
    const command = new AdminGetUserCommand({
      UserPoolId: process.env.userpool,
      Username: username
    });
    const response = await cognitoClient.send(command);

    const attributes = response.UserAttributes || [];
    const nameAttribute = attributes.find(attr => attr.Name === 'name');
    const roleAttribute = attributes.find(attr => attr.Name === 'custom:role');
    const name = nameAttribute ? nameAttribute.Value : 'Name attribute not found';
    const role = roleAttribute ? roleAttribute.Value : 'Role attribute not found';

    return { name, role };
  } catch (err) {
    console.error('Error retrieving user details:', err);
    return { name: 'Error', role: 'Error' }; // Default fallback
  }
};