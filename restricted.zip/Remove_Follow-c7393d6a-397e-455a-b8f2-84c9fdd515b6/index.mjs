import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, DeleteCommand } from "@aws-sdk/lib-dynamodb";

const config = { region: process.env.region };
const ddbClient = new DynamoDBClient(config);
const docClient = DynamoDBDocumentClient.from(ddbClient);

const headers = {
  'Access-Control-Allow-Methods': 'DELETE',
  'Access-Control-Allow-Origin': 'https://d1wx3p39zc5jck.cloudfront.net',
  'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token'
};

export const handler = async (event) => {
  const username = event.requestContext?.authorizer?.claims['username'] || '';

  if (!username || username === '') {
    return createErrorResponse(400, "Username is invalid / missing.");
  }

  let requestBody = {};
  if (typeof event.body === 'string') {
    requestBody = JSON.parse(event.body);
  }
  else {
    requestBody = event.body;
  }

  if (Object.keys(requestBody).length === 0) {
    return createErrorResponse(400, "Empty request data.");
  }

  const threadId = requestBody.threadId || '';
  const deleteParams = {
    TableName: process.env.table,
    Key: {
      PK: `USER#${username}`,
      SK: `FOLLOW#${threadId}`
    }
  };

  try {
    await docClient.send(new DeleteCommand(deleteParams));
    return createSuccessResponse(`Thread ${threadId} has been unfollowed successfully.`);
  }
  catch (error) {
    console.error("Error deleting item from DynamoDB:", error);
    return createErrorResponse(500, "Failed to delete item from DynamoDB.");
  }
};


const createSuccessResponse = (message) => ({
  statusCode: 200,
  headers,
  body: JSON.stringify({ message }),
});

const createErrorResponse = (statusCode, message) => ({
  statusCode,
  headers,
  body: JSON.stringify({ message }),
});
