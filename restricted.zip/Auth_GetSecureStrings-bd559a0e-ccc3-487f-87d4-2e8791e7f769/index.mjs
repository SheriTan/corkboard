import { SSMClient, GetParametersByPathCommand } from '@aws-sdk/client-ssm';
// Initialize the SSM client
const ssmClient = new SSMClient({ region: process.env.region });

const cors = {
    'Access-Control-Allow-Origin': 'https://d1wx3p39zc5jck.cloudfront.net',
    'Access-Control-Allow-Methods': 'GET',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token'
};

export const handler = async (event) => {
    try {
        // Validate query string parameters
        const queryStringParameters = event.queryStringParameters || {};
        const parameterPrefix = queryStringParameters['param'];

        if (!parameterPrefix) {
            return {
                statusCode: 400,
                headers: cors,
                body: JSON.stringify({
                    message: 'Missing required query parameters: param'
                })
            };
        }

        // Parameters for the getParametersByPath API call
        const params = {
            Path: `/${parameterPrefix}/`,
            Recursive: true,
            WithDecryption: true // Specify if the parameters are encrypted
        };

        // Call getParametersByPath directly from the client
        const data = await ssmClient.send(new GetParametersByPathCommand(params));

        // Extract parameter values from the response
        const parameters = data.Parameters.map(dparam => ({
            name: dparam.Name,
            value: dparam.Value
        }));

        // Return the parameter values in the response
        return {
            statusCode: 200,
            headers: cors,
            body: JSON.stringify({
                message: 'Parameters retrieved successfully',
                parameters: parameters
            })
        };
    }
    catch (err) {
        // Handle errors
        console.error("Error:", err);
        return {
            statusCode: 500,
            headers: cors,
            body: JSON.stringify({
                message: 'Failed to retrieve parameters',
                error: err.message // Display the error message
            })
        };
    }
};
