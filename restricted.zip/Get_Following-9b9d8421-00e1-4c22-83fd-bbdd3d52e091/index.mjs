import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, BatchGetCommand, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { CognitoIdentityProviderClient, AdminGetUserCommand } from '@aws-sdk/client-cognito-identity-provider';

const config = { region: process.env.region };
const cognitoClient = new CognitoIdentityProviderClient(config);
const ddbClient = new DynamoDBClient(config);
const docClient = DynamoDBDocumentClient.from(ddbClient);

const cors = {
  'Access-Control-Allow-Methods': 'GET',
  'Access-Control-Allow-Origin': 'https://d1wx3p39zc5jck.cloudfront.net',
  'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token'
};

export const handler = async (event) => {
  const username = event.requestContext?.authorizer?.claims['username'] || '';

  if (!username || username === '') {
    return {
      statusCode: 400,
      headers: cors,
      body: JSON.stringify({ message: "Username is invalid / missing." }),
    };
  }

  // Step 1: Retrieve the list of followed threads
  const followParams = {
    TableName: process.env.table,
    KeyConditionExpression: 'PK = :pk and begins_with(SK, :sk)',
    ExpressionAttributeValues: {
      ':pk': `USER#${username}`,
      ':sk': 'FOLLOW#'
    }
  };

  try {
    // Retrieve followed thread items
    const followData = await docClient.send(new QueryCommand(followParams));

    // Extract threadIds from followData
    const threadIds = followData?.Items?.map(item => item.thread) || [];
    let resThreads = [];
    let enrichedItems = [];
    // Step 2: Use BatchGetCommand to fetch details of all threads
    const batchGetParams = {
      RequestItems: {
        [process.env.table]: {
          Keys: threadIds.map(threadId => ({
            PK: `THREAD#${threadId}`,
            SK: `THREAD#${threadId}`
          }))
        }
      }
    };

    if (threadIds.length !== 0) {
      // Batch get details of all threads
      const batchGetData = await docClient.send(new BatchGetCommand(batchGetParams));
      resThreads = batchGetData.Responses[process.env.table];
    }

    if (resThreads.length !== 0) {
      enrichedItems = await Promise.all((resThreads).map(async (item) => {
        const userDetails = await retrieveUserDetails(item.author);
        return {
          ...item,
          userDetails
        };
      }));
    }

    return {
      statusCode: 200,
      headers: cors,
      body: JSON.stringify({ data: enrichedItems })
    };
  }
  catch (error) {
    return {
      statusCode: 400,
      headers: cors,
      body: JSON.stringify({ error: 'Could not fetch threads', details: error.message })
    };
  }
};

const retrieveUserDetails = async (username) => {
  try {
    const command = new AdminGetUserCommand({
      UserPoolId: process.env.userpool,
      Username: username
    });
    const response = await cognitoClient.send(command);

    const attributes = response.UserAttributes || [];
    const nameAttribute = attributes.find(attr => attr.Name === 'name');
    const roleAttribute = attributes.find(attr => attr.Name === 'custom:role');
    const name = nameAttribute ? nameAttribute.Value : 'Name attribute not found';
    const role = roleAttribute ? roleAttribute.Value : 'Role attribute not found';

    return { name, role };
  }
  catch (err) {
    console.error('Error retrieving user details:', err);
    return { name: 'Error', role: 'Error' }; // Default fallback
  }
};
