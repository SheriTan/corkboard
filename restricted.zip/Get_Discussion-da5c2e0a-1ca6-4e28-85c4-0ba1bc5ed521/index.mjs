import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { CognitoIdentityProviderClient, AdminGetUserCommand } from '@aws-sdk/client-cognito-identity-provider';

const config = { region: process.env.region };
const cognitoClient = new CognitoIdentityProviderClient(config);
const ddbClient = new DynamoDBClient(config);
const docClient = DynamoDBDocumentClient.from(ddbClient);

const cors = {
  'Access-Control-Allow-Methods': 'GET',
  'Access-Control-Allow-Origin': 'https://d1wx3p39zc5jck.cloudfront.net',
  'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token'
};

export const handler = async (event) => {
  const threadId = event.queryStringParameters['thread'] || '';

  const commentParams = {
    TableName: process.env.table,
    KeyConditionExpression: 'PK = :pk AND begins_with(SK, :sk)',
    ExpressionAttributeValues: {
      ':pk': `THREAD#${threadId}`,
      ':sk': 'COMMENT#'
    },
    ScanIndexForward: false // false to get results in descending order (newest first)
  };

  const threadParams = {
    TableName: process.env.table,
    KeyConditionExpression: 'PK = :pk AND SK = :sk',
    ExpressionAttributeValues: {
      ':pk': `THREAD#${threadId}`,
      ':sk': `THREAD#${threadId}`
    }
  };

  try {
    // Execute queries in parallel
    const [commentsData, threadData] = await Promise.all([
      docClient.send(new QueryCommand(commentParams)),
      docClient.send(new QueryCommand(threadParams))
    ]);

    const allItems = [
      ...(commentsData.Items || []),
      ...(threadData.Items || [])
    ];

    const enrichedItems = await Promise.all((allItems || []).map(async (item) => {
      const userDetails = await retrieveUserDetails(item.author);
      return {
        ...item,
        userDetails
      };
    }));

    return {
      statusCode: 200,
      headers: cors,
      body: JSON.stringify(enrichedItems)
    };
  }
  catch (error) {
    console.error('Error fetching data:', error);

    return {
      statusCode: 400,
      headers: cors,
      body: JSON.stringify({ error: 'Could not fetch threads', details: error.message })
    };
  }
};

const retrieveUserDetails = async (username) => {
  try {
    const command = new AdminGetUserCommand({
      UserPoolId: process.env.userpool,
      Username: username
    });
    const response = await cognitoClient.send(command);

    const attributes = response.UserAttributes || [];
    const nameAttribute = attributes.find(attr => attr.Name === 'name');
    const roleAttribute = attributes.find(attr => attr.Name === 'custom:role');
    const name = nameAttribute ? nameAttribute.Value : 'Name attribute not found';
    const role = roleAttribute ? roleAttribute.Value : 'Role attribute not found';

    return { name, role };
  }
  catch (err) {
    console.error('Error retrieving user details:', err);
    return { name: 'Error', role: 'Error' }; // Default fallback
  }
};
