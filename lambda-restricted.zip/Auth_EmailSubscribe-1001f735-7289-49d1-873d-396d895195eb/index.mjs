import { SNSClient, SubscribeCommand } from "@aws-sdk/client-sns";

const config = { region: process.env.region };
const snsClient = new SNSClient(config);

const cors = {
  'Access-Control-Allow-Methods': 'POST',
  'Access-Control-Allow-Origin': 'https://d1wx3p39zc5jck.cloudfront.net',
  'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token'
};

export const handler = async (event) => {
  let requestBody = {};
  if (typeof event.body === 'string') {
    requestBody = JSON.parse(event.body);
  }
  else {
    requestBody = event.body;
  }

  const email = requestBody.email;

  // Validate email
  if (!email) {
    return errorReturn(400, "Email is invalid or missing.");
  }

  const params = {
    TopicArn: process.env.sns,
    Protocol: 'email',
    Endpoint: email,
    ReturnSubscriptionArn: true
  };

  try {
    await snsClient.send(new SubscribeCommand(params));
    return successReturn('Subscription email sent.');
  }
  catch (error) {
    console.error('Failed to send subscription email:', error);
    return errorReturn(500, "Failed to send subscription email.");
  }
};

const errorReturn = (status, message) => {
  return {
    statusCode: status,
    headers: cors,
    body: JSON.stringify({ message })
  };
};

const successReturn = (message) => {
  return {
    statusCode: 200,
    headers: cors,
    body: JSON.stringify({ message })
  };
};
