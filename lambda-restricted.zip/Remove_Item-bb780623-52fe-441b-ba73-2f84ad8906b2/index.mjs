import { S3Client, DeleteObjectCommand, DeleteObjectsCommand } from '@aws-sdk/client-s3';
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, BatchWriteCommand, QueryCommand } from "@aws-sdk/lib-dynamodb";

const config = { region: process.env.region };
const s3Client = new S3Client(config);
const ddbClient = new DynamoDBClient(config);
const docClient = DynamoDBDocumentClient.from(ddbClient);

const headers = {
  'Access-Control-Allow-Methods': 'DELETE',
  'Access-Control-Allow-Origin': 'https://d1wx3p39zc5jck.cloudfront.net',
  'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token'
};

export const handler = async (event) => {
  const username = event.requestContext?.authorizer?.claims['username'] || '';

  if (!username || username === '') {
    return createErrorResponse(400, "Username is invalid / missing.");
  }

  let requestBody = {};
  if (typeof event.body === 'string') {
    requestBody = JSON.parse(event.body);
  }
  else {
    requestBody = event.body;
  }

  if (Object.keys(requestBody).length === 0) {
    return createErrorResponse(400, "Empty request data.");
  }

  const objectKey = requestBody.key || '';
  let s3Params = { Bucket: process.env.bucket };

  if (objectKey === '') {
    const skTypes = ['THREAD', 'COMMENT', 'FOLLOW'];
    let deleteDBList = [];
    let deleteObjList = [];

    for (const type of skTypes) {
      const queryParams = {
        TableName: process.env.table,
        IndexName: 'userhistory-index',
        KeyConditionExpression: 'author = :uid and begins_with(SK, :sk)',
        ExpressionAttributeValues: {
          ':uid': username,
          ':sk': `${type}#`
        }
      };
      
      console.log(queryParams)

      try {
        const resultSet = await docClient.send(new QueryCommand(queryParams));
        console.log(resultSet)
        if (resultSet.Items.length > 0) {
          deleteDBList = deleteDBList.concat(resultSet.Items);
          resultSet.Items.forEach((item) => {
            if (item.attachments && item.attachments.length > 0) {
              deleteObjList = deleteObjList.concat(item.attachments.map((key) => ({ Key: key })));
            }
          });
        }
      } catch (queryErr) {
        return createErrorResponse(400, `Error occurred during ${type} query: ${queryErr.message}`);
      }
    }

    const dbbatchSize = 25;
    const s3batchSize = 1000;

    for (let ddbIndex = 0, s3Index = 0; ddbIndex < deleteDBList.length || s3Index < deleteObjList.length;) {
      const dbbatchItems = deleteDBList.slice(ddbIndex, ddbIndex + dbbatchSize);
      const s3batchItems = deleteObjList.slice(s3Index, s3Index + s3batchSize);

      try {
        await Promise.all([
          deleteItems(dbbatchItems),
          deleteObjects(s3batchItems, s3Params)
        ]);
      } catch (err) {
        return createErrorResponse(400, `Error occurred during deletion: ${err.message}`);
      }

      ddbIndex += dbbatchSize;
      s3Index += s3batchSize;
    }

    return createSuccessResponse("All items deleted successfully.");
  } else {
    s3Params = { ...s3Params, Key: objectKey };

    try {
      await s3Client.send(new DeleteObjectCommand(s3Params));
      return createSuccessResponse("Object deleted successfully.");
    } catch (s3Err) {
      return createErrorResponse(400, `Error occurred during object deletion: ${s3Err.message}`);
    }
  }
};

const deleteItems = async (itemsToDelete) => {
  const deleteRequests = itemsToDelete.map(item => ({
    DeleteRequest: {
      Key: { 'PK': item.PK, 'SK': item.SK }
    }
  }));

  const batchDeleteParams = { RequestItems: { [process.env.table]: deleteRequests } };
  await docClient.send(new BatchWriteCommand(batchDeleteParams));
};

const deleteObjects = async (objectsToDelete, s3Params) => {
  s3Params = { ...s3Params, Delete: { Objects: objectsToDelete } };
  await s3Client.send(new DeleteObjectsCommand(s3Params));
};

const createSuccessResponse = (message) => ({
  statusCode: 200,
  headers,
  body: JSON.stringify({ message }),
});

const createErrorResponse = (statusCode, message) => ({
  statusCode,
  headers,
  body: JSON.stringify({ message }),
});
