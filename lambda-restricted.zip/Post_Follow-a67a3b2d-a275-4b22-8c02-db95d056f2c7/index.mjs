import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { PutCommand, DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

const config = { region: process.env.region };
const ddbClient = new DynamoDBClient(config);
const docClient = DynamoDBDocumentClient.from(ddbClient);

const cors = {
  'Access-Control-Allow-Methods': 'POST',
  'Access-Control-Allow-Origin': 'https://d1wx3p39zc5jck.cloudfront.net',
  'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token'
};


export const handler = async (event) => {
  const username = event.requestContext?.authorizer?.claims['username'];

  if (!username || username === '') {
    return {
      statusCode: 400,
      headers: cors,
      body: JSON.stringify({ message: "Username is invalid / missing." }),
    };
  }

  let requestBody = {};
  if (typeof event.body === 'string') {
    requestBody = JSON.parse(event.body);
  }
  else {
    requestBody = event.body;
  }

  if (Object.keys(requestBody).length === 0) {
    return {
      statusCode: 400,
      headers: cors,
      body: JSON.stringify({ message: "Empty request data." })
    };
  }

  const threadId = requestBody.threadId || '';
  const followParams = {
    TableName: process.env.table,
    Item: {
      PK: `USER#${username}`,
      SK: `FOLLOW#${threadId}`,
      author: username,
      thread: threadId,
      created_dt: new Date().getTime()
    }
  };

  try {
    await docClient.send(new PutCommand(followParams));
    return {
      statusCode: 200,
      headers: cors,
      body: JSON.stringify({ message: `Thread ${threadId} has been followed successfully.` })
    };
  }
  catch (error) {
    console.error("Error following post ${threadId} in DynamoDB:", error);
    return {
      statusCode: 500,
      headers: cors,
      body: JSON.stringify({ message: `Error following post ${threadId}.` })
    };
  }
};
