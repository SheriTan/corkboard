import { S3Client, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
const s3Client = new S3Client({ region: process.env.region });

const cors = {
  'Access-Control-Allow-Methods': 'GET',
  'Access-Control-Allow-Origin': 'https://d1wx3p39zc5jck.cloudfront.net',
  'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token'
};

export const handler = async (event) => {
  const objectKey = event.queryStringParameters?.key || '';

  if (objectKey && objectKey !== '') {
    const params = {
      Bucket: process.env.bucket,
      Key: objectKey
    };

    try {
      const signedUrl = await getSignedUrl(s3Client, new GetObjectCommand(params), { expiresIn: 60 });

      return {
        statusCode: 200,
        headers: cors,
        body: JSON.stringify({ signedUrl })
      };
    }
    catch (error) {
      return {
        statusCode: 400,
        headers: cors,
        body: JSON.stringify({ message: "Error occurred during signedUrl retrieval: " + error.message })
      };
    }


  }
  else {
    return {
      statusCode: 400,
      headers: cors,
      body: JSON.stringify({ message: "Empty request key." })
    };
  }
};
