import { CognitoIdentityProviderClient, AdminGetUserCommand } from '@aws-sdk/client-cognito-identity-provider';
import { S3Client, ListObjectsV2Command, CopyObjectCommand } from "@aws-sdk/client-s3";
import { createPresignedPost } from "@aws-sdk/s3-presigned-post";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { PutCommand, DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import { Snowflake } from "nodejs-snowflake";

const config = { region: process.env.region };
const cognitoClient = new CognitoIdentityProviderClient(config);
const s3Client = new S3Client(config);
const ddbClient = new DynamoDBClient(config);
const docClient = DynamoDBDocumentClient.from(ddbClient);
const snowflake = new Snowflake();

const cors = {
  'Access-Control-Allow-Methods': 'POST',
  'Access-Control-Allow-Origin': 'https://d1wx3p39zc5jck.cloudfront.net',
  'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token'
};

const tempPrefix = 'temp'; // For file prefix (different from etype)
const postPrefix = 'post'; // For file prefix (different from etype)

export const handler = async (event) => {
  const username = event.requestContext?.authorizer?.claims['username'];

  if (!username || username === '') {
    return {
      statusCode: 400,
      headers: cors,
      body: JSON.stringify({ message: "Username is invalid / missing." }),
    };
  }

  let requestBody = {};
  if (typeof event.body === 'string') {
    requestBody = JSON.parse(event.body);
  }
  else {
    requestBody = event.body;
  }

  if (Object.keys(requestBody).length === 0) {
    return {
      statusCode: 400,
      headers: cors,
      body: JSON.stringify({ message: "Empty request data." })
    };
  }

  const etype = requestBody.type || ''; // For conditional checking
  let postID = requestBody.postID || '';
  let attachment = requestBody.attachment || {};
  let s3ObjectsList = [];

  // Generate ID if there is none
  if (!postID || postID === "") {
    postID = generateSnowflakeID();
  }

  if (!etype || etype === '' || (etype !== 'temp' && etype !== 'post')) {
    return {
      statusCode: 400,
      headers: cors,
      body: JSON.stringify({ message: "Config error: invalid process." })
    };
  }
  else {
    try {
      if (etype === 'post') {
        // Event Type: Post, To look up all temporary objects in prefix
        const searchParams = {
          Bucket: process.env.bucket,
          Delimiter: '/',
          Prefix: `${tempPrefix}/${postID}/`
        };

        const searchRes = await s3Client.send(new ListObjectsV2Command(searchParams));
        if (searchRes.Contents && searchRes.Contents.length !== 0) {
          s3ObjectsList = searchRes.Contents.map(content => content.Key.replace(tempPrefix, postPrefix)).filter(key => key.startsWith(`${postPrefix}/${postID}/`) && key !== `${postPrefix}/${postID}/`);
        }

        let thread = '',
          comment = '',
          SK = '';
        if (requestBody.parentID && requestBody.parentID !== '') {
          thread = requestBody.parentID.toString();
          comment = postID.toString();
          SK = `COMMENT#${comment}`;
        }
        else {
          thread = postID.toString();
          comment = 'NA';
          SK = `THREAD#${thread}`;
        }

        let itemConfig = {
          PK: `THREAD#${thread}`,
          SK: SK,
          thread: thread,
          comment: comment,
          author: username,
          content: requestBody.content,
          created_dt: new Date().getTime(),
          attachments: s3ObjectsList
        };

        let followConfig = {
          PK: `USER#${username}`,
          SK: `FOLLOW#${thread}`,
          author: username,
          thread: thread,
          created_dt: new Date().getTime()
        };

        await Promise.all([
          copyS3Objects(s3ObjectsList),
          docClient.send(new PutCommand({ TableName: process.env.table, Item: itemConfig })),
          docClient.send(new PutCommand({ TableName: process.env.table, Item: followConfig })),
        ]);

        itemConfig = {
          ...itemConfig,
          userDetails: await retrieveUserDetails(username)
        };

        const createdItems = {
          posts: itemConfig,
          follows: followConfig
        };

        return {
          statusCode: 200,
          headers: cors,
          body: JSON.stringify({ message: "Post uploaded successfully.", data: createdItems })
        };

      }
      else if (etype === 'temp') {
        if (Object.keys(attachment).length !== 0) {
          // Event Type: Temp, To generate presigned post for user upload
          const signedParams = {
            Bucket: process.env.bucket,
            Key: `${tempPrefix}/${postID}/${attachment['name']}`,
            Conditions: [
              ["content-length-range", 0, 1048576], // 1 MB max size
              ["starts-with", "$Content-Type", "multipart/form-data"],
            ],
            Fields: {
              "Content-Type": "multipart/form-data"
            },
            Expires: 60
          };

          const presignedPostData = await createPresignedPost(s3Client, signedParams);

          return {
            statusCode: 200,
            headers: cors,
            body: JSON.stringify({ message: "Presigned URL generated successfully.", data: presignedPostData })
          };
        }
      }
    }
    catch (err) {
      console.error('Error occurred:', err);
      return {
        statusCode: 400,
        headers: cors,
        body: JSON.stringify({ message: "Error occurred: " + err.message })
      };
    }
  }
};

const generateSnowflakeID = () => {
  return snowflake.getUniqueID().toString();
};

const copyS3Objects = async (objectsList) => {
  if (objectsList.length === 0) {
    return;
  }

  await Promise.all(objectsList.map(async (key) => {
    const copyParams = {
      Bucket: process.env.bucket,
      CopySource: `${process.env.bucket}/${key.replace(postPrefix, tempPrefix)}`,
      Key: key
    };

    try {
      await s3Client.send(new CopyObjectCommand(copyParams));
    }
    catch (copyErr) {
      console.error('Error during copying:', copyErr);
      throw new Error(`Error occurred during migration of data: ${copyErr.message}`);
    }
  }));
};

const retrieveUserDetails = async (username) => {
  const command = new AdminGetUserCommand({
    UserPoolId: process.env.userpool,
    Username: username
  });

  const response = await cognitoClient.send(command);

  // Extract user attributes
  const attributes = response.UserAttributes;
  const nameAttribute = attributes.find(attr => attr.Name === 'name');
  const roleAttribute = attributes.find(attr => attr.Name === 'custom:role');
  const name = nameAttribute ? nameAttribute.Value : 'Name attribute not found';
  const role = roleAttribute ? roleAttribute.Value : 'Role attribute not found';

  return { name, role };
};
