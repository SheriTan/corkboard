import { SSMClient, GetParameterCommand } from '@aws-sdk/client-ssm';

const ssmClient = new SSMClient({ region: 'us-east-1' });

export const handler = async (event, context) => {
    const params = {
        Name: '/corkboard/app_client_id', // Replace with your parameter name
        WithDecryption: true // Decrypt the parameter value
    };

    try {
        const command = new GetParameterCommand(params);
        const data = await ssmClient.send(command);
        return {
            statusCode: 200,
            body: JSON.stringify(data.Parameter.Value)
        };
    } catch (err) {
        return {
            statusCode: 500,
            body: JSON.stringify({ error: err.message })
        };
    }
};